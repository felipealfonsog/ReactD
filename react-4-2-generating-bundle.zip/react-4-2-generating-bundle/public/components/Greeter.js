function greeter () {
  document.write('From greeter function');
}

module.exports = greeter;
